
Image attribution

Following images were used in preview. These images are not included in template source files.

•	By rosshuggett (http://www.flickr.com/photos/rosshuggett/4141772878/in/set-72157622893419072) - 2.0 Generic (CC BY 2.0)
•	By Victor1558 (http://www.flickr.com/photos/76029035@N02/6829334723/in/photostream) - Attribution 2.0 Generic (CC BY 2.0)
•	By By jayhem (http://www.flickr.com/photos/jayhem/3600002571/in/set-72157619582335578) - Attribution 2.0 Generic (CC BY 2.0)
•	By Victor1558 (http://www.flickr.com/photos/76029035@N02/6829478403/in/photostream) - Attribution 2.0 Generic (CC BY 2.0)
•	By Eneas (http://www.flickr.com/photos/eneas/4734975172/in/set-72157604236492218) - Attribution 2.0 Generic (CC BY 2.0)
•	By pedrosimoes7 (http://www.flickr.com/photos/pedrosimoes7/4198801198/in/set-72157616722082961) - Attribution 2.0 Generic (CC BY 2.0)
•	By az1172 (http://www.flickr.com/photos/az1172/2350604344/in/set-72157604192132711) - Attribution ShareAlike 2.0 Generic (CC BY-SA 2.0)
•	By vramak (http://www.flickr.com/photos/vramak/3499502280/in/photostream) - Attribution 2.0 Generic (CC BY 2.0)
•	By Fausto Hernandez Photography (http://www.flickr.com/photos/faustohernandez/2881041319/in/photostream/) - Attribution 2.0 Generic (CC BY 2.0)
•	By maha-online (http://www.flickr.com/photos/maha-online/1555343940/in/set-1345351) - Attribution ShareAlike 2.0 Generic (CC BY-SA 2.0)

•	Placeholders http://www.placehold.it/


Plugins attribution

Following plugins were used in template

•	Twitter Bootstrap - http://twitter.github.com/bootstrap/index.html - Attribution Apache License Version 2.0, January 2004
•	Jquery - www.jquery.com - Attribution MIT License
•	jquery.tweet.js - By Todd Matthews & Steve Purcell (http://tweet.seaofclouds.com/) - Attribution (https://github.com/seaofclouds/tweet/blob/master/LICENSE.txt)
•	jquery.refineslide.min.js - By Alex Dunphy (http://alexdunphy.github.com/refineslide/) - Attribution (https://github.com/alexdunphy/refineslide/blob/master/LICENSE.txt)
•	jquery.flexslider-min.js - By WooThemes (http://www.woothemes.com/flexslider/) - Attribution (https://github.com/woothemes/FlexSlider/blob/master/README.mdown) GPLv2
•	css-browser-selector.js - By Rafael Lima (http://rafael.adm.br/css_browser_selector/) - Attribution 2.5 Generic (CC BY 2.5)
•	lightbox.js - By Lokesh Dhakar (http://lokeshdhakar.com/projects/lightbox2/) - Attribution 2.5 Generic (CC BY 2.5)
•	jQuery.BlackAndWhite.min.js - By Gianluca Guarini (http://gianlucaguarini.com/canvas-experiments/jQuery.BlackAndWhite/) - Attribution (https://github.com/GianlucaGuarini/jQuery.BlackAndWhite/blob/master/LICENSE.txt)
•	jquery.flickrush.js - By Philip Beel (http://theodin.co.uk/blog/development/flickrush-jquery-flickr-plugin.html) - Attribution Dual licensed under the MIT and GPL
•	Hide Dropdown Menu and replace it with select menu (http://css-tricks.com/convert-menu-to-dropdown/) - By Chris Coyier - tutorial



Dropdown Menu

•	Dropdown Menu by Live Web Initiatives (http://www.lwis.net/free-css-drop-down-menu/) - Attribution licensed under the MIT License and GNU License



IE HACKS

•	Pie css3 by Jason Johnston (http://css3pie.com/) - Attribution Apache License and General Public License (GPL) Version 2
•	html5shim http://html5shim.googlecode.com/svn/trunk/html5.js
•	ie7-js by Dean Edwards


FONTS

•	Websymbols by Just Be Nice studio (http://www.justbenicestudio.com/studio/websymbols/) - Attribution License OFL
•	Open Sans by Steve Matteson (http://www.google.com/webfonts#UsePlace:use/Collection:Open+Sans)
